#pragma once
class Diplomacy
{};

