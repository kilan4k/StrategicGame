#pragma once
class Technology
{};

